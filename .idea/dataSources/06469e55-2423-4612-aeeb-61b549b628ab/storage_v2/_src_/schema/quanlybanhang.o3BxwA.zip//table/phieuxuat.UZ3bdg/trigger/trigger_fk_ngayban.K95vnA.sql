create definer = root@localhost trigger trigger_FK_Ngayban
    before insert
    on phieuxuat
    for each row
begin
    if NEW.NgayBan <= curdate()
    then
        signal sqlstate '45000' set message_text = 'ngày bán khong bé hơn ngày hiện tại';
    end if;
end;

