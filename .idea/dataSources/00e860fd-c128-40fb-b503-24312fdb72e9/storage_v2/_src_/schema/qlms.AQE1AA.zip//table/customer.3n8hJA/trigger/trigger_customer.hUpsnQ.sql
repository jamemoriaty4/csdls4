create definer = root@localhost trigger trigger_Customer
    before insert
    on customer
    for each row
begin
    if new.CreateDate <= curdate()
    then
        signal sqlstate '45000' set message_text = 'ngày bán khong bé hơn ngày hiện tại';
    end if;
end;

