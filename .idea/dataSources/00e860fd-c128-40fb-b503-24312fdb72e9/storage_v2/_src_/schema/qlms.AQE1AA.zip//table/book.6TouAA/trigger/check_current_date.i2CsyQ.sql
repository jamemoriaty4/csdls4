create definer = root@localhost trigger check_current_date
    before insert
    on book
    for each row
    set new.CreatedDate = curdate();

