create definer = root@localhost trigger trigger_cost
    before insert
    on ticketdetail
    for each row
BEGIN
    DECLARE book_price DECIMAL(10,2);
    SELECT Price INTO book_price
    FROM Book
    WHERE Book.ID = NEW.BookID;

    SET NEW.DeposiPrice = book_price;
END;

