create definer = root@localhost trigger check_current_Ticket_Date
    before insert
    on ticket
    for each row
    set new.TicketDate = now();

